using System;

public class Dummy
{
}